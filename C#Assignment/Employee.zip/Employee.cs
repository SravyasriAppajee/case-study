﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignments
{
        interface IStudent
        {
            string LibCardNumber
            {
                get;
                set;
            }
            int Year
            {
                get;
                set;
            }
            void Register();
            void PostCourseWork(string work);
        }
        class PartTimeStudent : IStudent
        {
            string name;
            int year;
            public string LibCardNumber
            {
                get => name;
                set => name = value;
            }
            public int Year
            {
                get => year;
                set => year = value;
            }

            public void Register()
            {
                Console.Write("\nEnter the library card number:");
                string LibCardNumber = Console.ReadLine();
                Console.Write("\nEnter the year:");
                int Year = int.Parse(Console.ReadLine());
                Console.Write("\nThe details you've entered are as follows\n");
                Console.WriteLine("your library card number is: "+LibCardNumber + "\nYear is:" + Year);
            }

            public void PostCourseWork(string work)
            {
                Console.WriteLine("\nYour status is:" + work);
            }
        }
    class Employee
    {
            public static void Main()
            {
                PartTimeStudent e = new PartTimeStudent();
                Console.WriteLine("\nGive the below details");
                e.Register();
                Console.Write("\nEnter post course work name:");
                string PostCourseworkString = Console.ReadLine();
                e.PostCourseWork(PostCourseworkString);
                Console.ReadLine();
            }

        }
    }
