﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project1
{
    public enum Day1
    {
        Monday = 1, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday
    }
    class WorkorHol
    {
            public static void Main()
            {
                Console.WriteLine("Enter number");
                int number = int.Parse(Console.ReadLine());
                if (number > 0 && number <= 7)
                {

                    if (number > 0 && number < 6)
                    {
                        if (number == (int)Day1.Monday ||
                            number == (int)Day1.Tuesday ||
                            number == (int)Day1.Wednesday ||
                            number == (int)Day1.Thursday ||
                            number == (int)Day1.Friday)
                        {
                            Console.WriteLine("position:" + (number - 1) + " number:" + number);
                        }

                    }
                    else if (number == (int)DayofWeek.Saturday ||
                        number == (int)DayofWeek.Sunday)
                        Console.WriteLine("position:" + (number - 1) + " number:" + number);

                }
                else
                {
                    Console.WriteLine("Enter valid number");
                }
            }
    }
}
