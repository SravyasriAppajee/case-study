﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project1
{
    class Bubblesort
    {
        static void Main()
        {
            Console.WriteLine("Enter number of elements :");
            int numberofinputs = int.Parse(Console.ReadLine());
            int start = 0;
            int end = numberofinputs - 1;
            int middle = (start + end) / 2;
            int[] Inputs = new int[numberofinputs];
            Console.WriteLine("Enter elements:");
            for (int i = 0; i < numberofinputs; i++)
            {
                Inputs[i] = int.Parse(Console.ReadLine());
            }
            Console.WriteLine("Enter the search element:");
            int searchElement = int.Parse(Console.ReadLine());

            while (start <= end)
            {
                if (Inputs[middle] < searchElement)
                {
                    start = middle + 1;
                }
                else if (Inputs[middle] == searchElement)
                {
                    Console.WriteLine("Element " + searchElement + " is found at the location of " + (middle + 1));
                    break;
                }
                else
                {
                    end = end - 1;
                }
                middle = (start + end) / 2;
            }
            if (start > end)
                Console.WriteLine(" " +searchElement + " is not found");

        }
    }
}
