﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace project1
{
    public enum Day
    {
        Monday = 1, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday
    }
    class workingorholiday
    {
            static void Main(string[] args)
            {
                Console.WriteLine("Enter number");
                int number = int.Parse(Console.ReadLine());
                if (number > 0 && number <= 7)
                {

                    if (number > 0 && number < 6)
                    {
                        if (number == (int)Day.Monday ||
                             number == (int)Day.Tuesday ||
                             number == (int)Day.Wednesday ||
                             number == (int)Day.Thursday ||
                             number == (int)Day.Friday)
                            Console.WriteLine("Working day");

                    }
                    else
                        Console.WriteLine("Holiday");
                }
                else
                {
                    Console.WriteLine("Enter a valid number");
                }
            }
    }

}