﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignments
{
    class Circle
    {
            public double Radius
            {
                set;
                get;
            }
            public double CalculateDiameter()
            {
                double Diameter = 2 * Radius;
                return Diameter;
            }
            public double CalculateArea()
            {
                double Area = 3.14 * Radius * Radius;
                return Area;
            }
    }
     class CircleValues
     {
         public static void Main(string[] args)
         {
             Console.WriteLine("enter the radius of the circle:"); 
             double radius = double.Parse(Console.ReadLine());
             Circle cir = new Circle();
             cir.Radius = radius;
             Console.Write("Diameter of the given circle is: ");
             Console.WriteLine(cir.CalculateDiameter());
             Console.Write("Area of the given circle is: ");
             Console.WriteLine(cir.CalculateArea());
         }
     }
}

